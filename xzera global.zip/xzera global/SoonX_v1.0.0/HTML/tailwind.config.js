tailwind.config = {
    darkMode: "class",
    theme: {
        fontFamily: {
            body: ['League Spartan', 'sans-serif'],
        },
    }
}